Fluxo Normal:

$ ./trab5 < program.cm

Gera código Assembly:

$ ./trab5 -d < program.cm